import java.util.Scanner;

public class Purchasers extends Customer 
{
    private String Purposeofpurchasing;
    Scanner sc=new Scanner(System.in);
    Purchasers [] plist;
    int p;
    int c;
    public Purchasers()
    {
        plist= new Purchasers[100];
    }

    public Purchasers(String name , String Purposeofpurchasing , long contactno)
    {
        this.name = name;
        this.Purposeofpurchasing = Purposeofpurchasing;
        this.contactno = contactno;
        
    }
    
    public String getpurposeofpurchasing()
    {
        return Purposeofpurchasing;
    }
    
    public void setpurposeofpurchasing(String Purposeofpurchasing)
    {
        this.Purposeofpurchasing = Purposeofpurchasing;
    }
    
     public void inputPurchasers ()
   {
       
       for (int i=0 ; i<1 ; i++)
       {
       System.out.println("\n \t\t ----- PURCHASER -----");
       System.out.println("\n Name : ");
       name = sc.nextLine();
       System.out.println("\n Purpose of Purchasing : ");
       Purposeofpurchasing = sc.nextLine();
       System.out.println("\n Contact Number : ");
       contactno = sc.nextLong();
       
       
       plist[c] = new Purchasers( name , Purposeofpurchasing , contactno);
       c++;
       }
       
       
}

     @Override
     public String toString()
     {
         return "Name is " + name + "\nPurpose of purchasing is " + Purposeofpurchasing + "\nContactNo is " + contactno ;
     }

      public void Displaypurchaserslist()
   {
       System.out.println("\t\t--- PURCHASERS RECORD --- \n");
       for (int j=0 ; j< c ; j++) {
           System.out.println(""+plist[j].toString());
       }
}
}
