import java.util.Scanner;

public class Donor extends Customer 
{
    int weight;
    int d;
    int c =0;
    String bloodgroup;
    Scanner sc=new Scanner(System.in);
    Donor [] dlist;
    
    public Donor()
   {
    dlist= new Donor[100];

   }    

   public Donor(String name , int age , long contactno, String bloodgroup,int weight)
   {
       this.name = name;
       this.age = age;
       this.contactno = contactno;
       this.bloodgroup=bloodgroup;
       this.weight=weight;
   }
    public void inputDonor ()
   {
       
       for (int i=0 ; i<1 ; i++)
       {
       System.out.println("\n \t\t ----- DONOR -----");
       System.out.println(" Name : ");
       name = sc.next();
       System.out.println(" Age : ");
       age = sc.nextInt();
       if (age >=18){
          System.out.println(" Weight : ");
          weight = sc.nextInt();
          if (weight >= 45){
       System.out.println("Your Contact Number : ");
       contactno = sc.nextLong();
       System.out.println("\n Your blood group :\nChoose from: \n A+ \n A- \n B+ \n B- \n O+ \n O- \n AB+ \n AB-\n");
       bloodgroup = sc.next();
       
       dlist[c] = new Donor( name , age , contactno,bloodgroup,weight);
       c++;
          System.out.println("\n \t\t ------- DONOR ADDED ------- \n");}
       else{
       System.out.println("Sorry!Your weight must be atleast 45Kg ");
       }
       }
       else{
       System.out.println("Sorry!Your age must be atleast 18 ");
       }
       }

   }
 @Override
   public String toString(){
       return "\nName is :" + name +"\nAge is :" + age + "\nContact Number is :"+ contactno +"\nBlood Group is :"+ bloodgroup ;
       
   }
  
    public void Displaydonorlist()
   {
       System.out.println("\t\t--- DONORS RECORD --- \n");
       for (int j=0 ; j< c ; j++) {
           System.out.println(""+dlist[j].toString());
       }
   }
}