public class Customer {
    String name;
    int age;
    long contactno;
   
public Customer()
{
    
}

public Customer(String name , int age , long contactno)
{
    this.name = name;
    this.age = age;
    this.contactno = contactno;
}
    
}
