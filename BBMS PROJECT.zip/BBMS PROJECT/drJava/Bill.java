import java.util.Scanner;

public class Bill 
{
    Scanner sc = new Scanner(System.in);
    int wantedbloodgroup;
    
    public  void DisplayBill()
    {
        System.out.println("\nThe blood group you want :\nChoose from: \n1.A+ \n2.A- \n3.B+ \n4.B- \n5.O+ \n6.O- \n7.AB+ \n8.AB-\n");
        wantedbloodgroup = sc.nextInt();
        
        switch(wantedbloodgroup)
        {
            case 1:
            {
                System.out.println("\t\t       Blood Bank     ");
                System.out.println("\n\t\t ***** BILL *****");
                System.out.println("\nBlood group you wanted : A+");
                System.out.println("\nCost : Rs 1000/-\n");
                break;
            }
                 case 2:
            {
                System.out.println("\t\t      Blood Bank     ");
                System.out.println("\n\t\t ***** BILL *****");
                System.out.println("\nBlood group you wanted : A-");
                System.out.println("\nCost : Rs 1000/-\n");
                break;
            }
                 case 3:
            {
                System.out.println("\t\t       Blood Bank     ");
                System.out.println("\n\t\t ***** BILL *****");
                System.out.println("\nBlood group you wanted : B+");
                System.out.println("\nCost : Rs 1000/-\n");
            }
                 case 4:
            {
                System.out.println("\t\t       Blood Bank     ");
                System.out.println("\n\t\t ***** BILL *****");
                System.out.println("\nBlood group you wanted : B-");
                System.out.println("\nCost : Rs 1000/-\n");
                break;
            }
                 case 5:
            {
                System.out.println("\t\t       Blood Bank     ");
                System.out.println("\n\t\t ***** BILL *****");
                System.out.println("\nBlood group you wanted : O+");
                System.out.println("\nCost : Rs 5000/-\n");
                break;
            }
                 case 6:
            {
                System.out.println("\t\t       Blood Bank     ");
                System.out.println("\n\t\t ***** BILL *****");
                System.out.println("\nBlood group you wanted : O-");
                System.out.println("\nCost : Rs 5000/-\n");
                break;
            }
                 case 7:
            {
                System.out.println("\t\t       Blood Bank     ");
                System.out.println("\n\t\t ***** BILL *****");
                System.out.println("\nBlood group you wanted : AB+");
                System.out.println("\nCost : Rs 1000/-\n");
                break;
            }
                 case 8:
            {
                System.out.println("\t\t       Blood Bank     ");
                System.out.println("\n\t\t ***** BILL *****");
                System.out.println("\nBlood group you wanted : AB-");
                System.out.println("\nCost : Rs 1000/-\n");
                break;
            }
        }
       
        
    }
    
    
}
