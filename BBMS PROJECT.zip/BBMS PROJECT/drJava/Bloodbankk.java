import java.util.Scanner;


public class Bloodbankk {
    public static void main(String[] args) 
    {
     Donor Don = new Donor();
    // Questions Doc = new Questions ();
     Purchasers Pur=new Purchasers();   
     Bill B1 = new Bill();
     Scanner sc=new Scanner(System.in);
     int back;   
     int BMS;
        
        
       do { 
            System.out.println(" \t\t\t ------ Blood Bank Manegement System ------");
            System.out.println("\n\t\t What Do You Want To Do?");
            System.out.println("\n \t\t1. Donate Blood");
            System.out.println(" \t\t2. Purchase Blood \n\t\t3. To Print Donors Record. \n\t\t4. To Print Purchasers Record.");
            System.out.println(" \t\t5. Exit.\n");    
                 BMS=sc.nextInt();
                
                switch(BMS)
                {
                    case 1:
                    {
                        Don.inputDonor();
                       
                        System.out.println("\n\nPress 0 to get back to reception.\n");
                        back = sc.nextInt();
                       break;
                    }
                    
                    case 2:
                    {
                        Pur.inputPurchasers();
                        B1.DisplayBill();
                        System.out.println("\nPress 0 to get back to reception.\n");
                        back = sc.nextInt();
                        break;
                    }
                    
                    case 3:
                    {
                        Don.Displaydonorlist();
                        System.out.println("\nPress 0 to get back to reception.\n");
                        back = sc.nextInt();
                        break;
                    }
                    
                    case 4:
                    {
                        Pur.Displaypurchaserslist();
                        System.out.println("\nPress 0 to get back to reception.\n");
                        back = sc.nextInt();
                        break;
                    }
                    
                    case 5:
                    {
                        System.exit(0);
                        break;
                    }
                            
                }
    }while (BMS!=5);
    }
    
}
